// ==================== FICHIER : lib/theme/app_theme.dart ====================
// Définition du thème sombre premium utilisé dans toute l'application.
// Toutes les constantes de design sont centralisées ici pour une maintenance facile.

import 'package:flutter/material.dart';

/// Palette de couleurs et tokens de design de l'application.
abstract final class AppColors {
  // Arrière-plans
  static const Color background = Color(0xFF0A0A0F);
  static const Color surface = Color(0xFF12121A);

  // Couleur accent laser / highlight
  static const Color laser = Color(0xFF00E5FF); // cyan lumineux
  static const Color laserGlow = Color(0x8000E5FF); // glow semi-transparent

  // Bordures glassmorphism
  static const Color glassBorder = Color(0x33FFFFFF);
  static const Color glassFill = Color(0x1AFFFFFF);

  // Textes
  static const Color textPrimary = Color(0xFFFFFFFF);
  static const Color textSecondary = Color(0x99FFFFFF);

  // Succès
  static const Color success = Color(0xFF00E676);
}

/// Tokens d'espacement cohérents.
abstract final class AppSpacing {
  static const double xs = 4.0;
  static const double sm = 8.0;
  static const double md = 16.0;
  static const double lg = 24.0;
  static const double xl = 32.0;
  static const double xxl = 48.0;
}

/// Rayons de coins cohérents.
abstract final class AppRadius {
  static const double sm = 8.0;
  static const double md = 16.0;
  static const double lg = 24.0;
  static const double xl = 32.0;
  static const Radius mdRadius = Radius.circular(md);
  static const BorderRadius mdBorderRadius = BorderRadius.all(mdRadius);
}

/// Définition du thème Material sombre premium.
abstract final class AppTheme {
  static ThemeData get darkTheme {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: AppColors.background,
      colorScheme: const ColorScheme.dark(
        primary: AppColors.laser,
        secondary: AppColors.laser,
        surface: AppColors.surface,
        onPrimary: Colors.black,
        onSecondary: Colors.black,
        onSurface: AppColors.textPrimary,
      ),
      textTheme: const TextTheme(
        headlineMedium: TextStyle(
          color: AppColors.textPrimary,
          fontSize: 22,
          fontWeight: FontWeight.w600,
          letterSpacing: 0.3,
        ),
        bodyMedium: TextStyle(
          color: AppColors.textSecondary,
          fontSize: 14,
          fontWeight: FontWeight.w400,
          letterSpacing: 0.5,
        ),
        labelSmall: TextStyle(
          color: AppColors.textSecondary,
          fontSize: 11,
          fontWeight: FontWeight.w500,
          letterSpacing: 1.2,
        ),
      ),
      iconTheme: const IconThemeData(color: AppColors.textPrimary, size: 24),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: AppColors.surface.withOpacity(0.95),
        contentTextStyle: const TextStyle(color: AppColors.textPrimary),
        shape: const RoundedRectangleBorder(
          borderRadius: AppRadius.mdBorderRadius,
        ),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }
}
