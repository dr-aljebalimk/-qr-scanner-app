// ==================== FICHIER : lib/widgets/success_flash.dart ====================
// Overlay d'animation de succès : un flash de couleur laser + checkmark
// qui apparaît brièvement quand un QR code valide est détecté.

import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

/// Overlay de succès animé (flash + icône check).
/// À placer dans un Stack au-dessus du scanner.
/// S'affiche en [show] = true, se cache sinon.
class SuccessFlash extends StatefulWidget {
  const SuccessFlash({super.key, required this.show});
  final bool show;

  @override
  State<SuccessFlash> createState() => _SuccessFlashState();
}

class _SuccessFlashState extends State<SuccessFlash>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _fadeAnim;
  late final Animation<double> _scaleAnim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );

    _fadeAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _ctrl, curve: const Interval(0.0, 0.4)),
    );
    _scaleAnim = Tween<double>(begin: 0.6, end: 1.0).animate(
      CurvedAnimation(parent: _ctrl, curve: Curves.elasticOut),
    );
  }

  @override
  void didUpdateWidget(SuccessFlash oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.show && !oldWidget.show) {
      _ctrl.forward(from: 0.0);
    } else if (!widget.show) {
      _ctrl.reverse();
    }
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (context, _) {
        if (_ctrl.isDismissed) return const SizedBox.shrink();

        return Opacity(
          opacity: _fadeAnim.value,
          child: Container(
            color: Colors.black.withOpacity(0.45),
            child: Center(
              child: Transform.scale(
                scale: _scaleAnim.value,
                child: Container(
                  width: 90,
                  height: 90,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: AppColors.success.withOpacity(0.12),
                    border: Border.all(
                      color: AppColors.success.withOpacity(0.8),
                      width: 2,
                    ),
                  ),
                  child: const Icon(
                    Icons.check_rounded,
                    size: 44,
                    color: AppColors.success,
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
