// ==================== FICHIER : lib/widgets/scanner_overlay.dart ====================
//
// Ce widget compose deux couches :
//   1. ScannerFramePainter  – dessine le cadre de scan + les coins décoratifs
//                             via CustomPainter (pas de rebuild Flutter inutile).
//   2. LaserLine            – une ligne cyan animée de haut en bas du cadre,
//                             implémentée avec AnimatedBuilder + Tween pour que
//                             l'animation soit pilotée par un seul AnimationController.
//
// Pourquoi CustomPainter pour le cadre et AnimatedBuilder pour le laser ?
//   • Le cadre est STATIQUE → CustomPainter évite tout rebuild d'arbre de widgets.
//   • Le laser est DYNAMIQUE → AnimatedBuilder ne reconstruit QUE la ligne,
//     pas le cadre ni les autres enfants du Stack.
//   • Cette combinaison donne une animation 60 fps sans jank.

import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

// ─────────────────────────────────────────────────────────────
// Constantes du viseur
// ─────────────────────────────────────────────────────────────

/// Taille du cadre de scan en fraction de la largeur d'écran.
const double kFrameSizeFraction = 0.72;

/// Longueur des coins décoratifs (en px).
const double kCornerLength = 28.0;

/// Épaisseur des coins décoratifs (en px).
const double kCornerStroke = 3.5;

/// Durée d'un aller-retour du laser.
const Duration kLaserDuration = Duration(milliseconds: 2200);

// ─────────────────────────────────────────────────────────────
// Widget principal : ScannerOverlay
// ─────────────────────────────────────────────────────────────

/// Superposition de scan : cadre animé + ligne laser.
/// [frameRect] est le rectangle occupé par le cadre dans l'écran.
class ScannerOverlay extends StatefulWidget {
  const ScannerOverlay({super.key, this.isScanning = true});

  /// Quand false, le laser est mis en pause (ex : pendant le traitement d'un code).
  final bool isScanning;

  @override
  State<ScannerOverlay> createState() => _ScannerOverlayState();
}

class _ScannerOverlayState extends State<ScannerOverlay>
    with SingleTickerProviderStateMixin {
  late final AnimationController _laserCtrl;
  late final Animation<double> _laserAnim;

  @override
  void initState() {
    super.initState();
    _laserCtrl = AnimationController(vsync: this, duration: kLaserDuration)
      ..repeat(reverse: true); // ping-pong haut ↔ bas

    // CurvedAnimation pour un mouvement plus naturel (ease-in-out)
    _laserAnim = CurvedAnimation(
      parent: _laserCtrl,
      curve: Curves.easeInOut,
    );
  }

  @override
  void didUpdateWidget(ScannerOverlay oldWidget) {
    super.didUpdateWidget(oldWidget);
    // Pause/reprise du laser selon l'état de scan
    if (widget.isScanning && !_laserCtrl.isAnimating) {
      _laserCtrl.repeat(reverse: true);
    } else if (!widget.isScanning && _laserCtrl.isAnimating) {
      _laserCtrl.stop();
    }
  }

  @override
  void dispose() {
    _laserCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final screenW = constraints.maxWidth;
        final screenH = constraints.maxHeight;

        // Calcul du cadre centré
        final frameSize = screenW * kFrameSizeFraction;
        final frameLeft = (screenW - frameSize) / 2;
        final frameTop = (screenH - frameSize) / 2 - 40; // légèrement au-dessus du centre
        final frameRect = Rect.fromLTWH(frameLeft, frameTop, frameSize, frameSize);

        return Stack(
          children: [
            // ── Couche 1 : Assombrissement des zones hors cadre ──
            _DimmingLayer(frameRect: frameRect, screenSize: Size(screenW, screenH)),

            // ── Couche 2 : Cadre décoratif (CustomPainter statique) ──
            CustomPaint(
              size: Size(screenW, screenH),
              painter: _ScannerFramePainter(frameRect: frameRect),
            ),

            // ── Couche 3 : Ligne laser animée ──
            AnimatedBuilder(
              animation: _laserAnim,
              builder: (context, _) {
                // Position verticale du laser : 0.0 = haut du cadre, 1.0 = bas
                final laserY =
                    frameRect.top + _laserAnim.value * frameRect.height;
                return _LaserLine(
                  left: frameRect.left,
                  right: frameRect.right,
                  y: laserY,
                );
              },
            ),
          ],
        );
      },
    );
  }
}

// ─────────────────────────────────────────────────────────────
// Couche d'assombrissement (hors cadre)
// ─────────────────────────────────────────────────────────────

/// Assombrit tout l'écran sauf la zone [frameRect].
/// Utilise un CustomPainter avec un Path contenant un trou.
class _DimmingLayer extends StatelessWidget {
  const _DimmingLayer({required this.frameRect, required this.screenSize});
  final Rect frameRect;
  final Size screenSize;

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      size: screenSize,
      painter: _DimmingPainter(frameRect: frameRect),
    );
  }
}

class _DimmingPainter extends CustomPainter {
  _DimmingPainter({required this.frameRect});
  final Rect frameRect;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.black.withOpacity(0.62);

    // Path plein écran avec un trou rectangulaire à coins arrondis
    final fullPath = Path()..addRect(Rect.fromLTWH(0, 0, size.width, size.height));
    final holePath = Path()
      ..addRRect(
        RRect.fromRectAndRadius(frameRect, const Radius.circular(20)),
      );

    // Soustraction du trou via l'opération evenOdd
    final combined = Path.combine(PathOperation.difference, fullPath, holePath);
    canvas.drawPath(combined, paint);
  }

  @override
  bool shouldRepaint(_DimmingPainter oldDelegate) =>
      oldDelegate.frameRect != frameRect;
}

// ─────────────────────────────────────────────────────────────
// Cadre décoratif (CustomPainter)
// ─────────────────────────────────────────────────────────────

/// Dessine les 4 coins lumineux du cadre de scan.
/// Utilise CustomPainter car c'est une forme statique : zéro rebuild.
class _ScannerFramePainter extends CustomPainter {
  _ScannerFramePainter({required this.frameRect});
  final Rect frameRect;

  @override
  void paint(Canvas canvas, Size size) {
    // ── Bordure extérieure fine du cadre ──
    final borderPaint = Paint()
      ..color = AppColors.laser.withOpacity(0.25)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0;
    canvas.drawRRect(
      RRect.fromRectAndRadius(frameRect, const Radius.circular(20)),
      borderPaint,
    );

    // ── Coins lumineux (arcs de coin) ──
    final cornerPaint = Paint()
      ..color = AppColors.laser
      ..style = PaintingStyle.stroke
      ..strokeWidth = kCornerStroke
      ..strokeCap = StrokeCap.round;

    // Ajout d'un glow sur les coins via un paint flou
    final glowPaint = Paint()
      ..color = AppColors.laserGlow
      ..style = PaintingStyle.stroke
      ..strokeWidth = kCornerStroke + 4
      ..strokeCap = StrokeCap.round
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4);

    _drawCorners(canvas, frameRect, cornerPaint);
    _drawCorners(canvas, frameRect, glowPaint);
  }

  /// Dessine les 4 coins en L du cadre.
  void _drawCorners(Canvas canvas, Rect r, Paint paint) {
    const cl = kCornerLength;
    const cr = 20.0; // coin radius du cadre

    // Coin supérieur gauche
    canvas.drawPath(
      Path()
        ..moveTo(r.left, r.top + cl)
        ..lineTo(r.left, r.top + cr)
        ..arcToPoint(
          Offset(r.left + cr, r.top),
          radius: const Radius.circular(cr),
          clockwise: true,
        )
        ..lineTo(r.left + cl, r.top),
      paint,
    );

    // Coin supérieur droit
    canvas.drawPath(
      Path()
        ..moveTo(r.right - cl, r.top)
        ..lineTo(r.right - cr, r.top)
        ..arcToPoint(
          Offset(r.right, r.top + cr),
          radius: const Radius.circular(cr),
          clockwise: false,
        )
        ..lineTo(r.right, r.top + cl),
      paint,
    );

    // Coin inférieur droit
    canvas.drawPath(
      Path()
        ..moveTo(r.right, r.bottom - cl)
        ..lineTo(r.right, r.bottom - cr)
        ..arcToPoint(
          Offset(r.right - cr, r.bottom),
          radius: const Radius.circular(cr),
          clockwise: false,
        )
        ..lineTo(r.right - cl, r.bottom),
      paint,
    );

    // Coin inférieur gauche
    canvas.drawPath(
      Path()
        ..moveTo(r.left + cl, r.bottom)
        ..lineTo(r.left + cr, r.bottom)
        ..arcToPoint(
          Offset(r.left, r.bottom - cr),
          radius: const Radius.circular(cr),
          clockwise: false,
        )
        ..lineTo(r.left, r.bottom - cl),
      paint,
    );
  }

  @override
  bool shouldRepaint(_ScannerFramePainter oldDelegate) =>
      oldDelegate.frameRect != frameRect;
}

// ─────────────────────────────────────────────────────────────
// Ligne Laser
// ─────────────────────────────────────────────────────────────

/// Ligne laser horizontale avec gradient et glow.
/// Repositionnée par AnimatedBuilder → rebuildée SEULEMENT cette ligne.
class _LaserLine extends StatelessWidget {
  const _LaserLine({
    required this.left,
    required this.right,
    required this.y,
  });

  final double left;
  final double right;
  final double y;

  @override
  Widget build(BuildContext context) {
    final width = right - left;

    return Positioned(
      left: left,
      top: y - 1.5, // centrer la ligne sur y
      child: SizedBox(
        width: width,
        height: 3,
        child: CustomPaint(painter: _LaserPainter(width: width)),
      ),
    );
  }
}

/// Dessine le gradient cyan + glow de la ligne laser.
class _LaserPainter extends CustomPainter {
  const _LaserPainter({required this.width});
  final double width;

  @override
  void paint(Canvas canvas, Size size) {
    // ── Glow large (halo) ──
    final glowPaint = Paint()
      ..shader = ui.Gradient.linear(
        Offset.zero,
        Offset(width, 0),
        [
          Colors.transparent,
          AppColors.laserGlow,
          AppColors.laser,
          AppColors.laserGlow,
          Colors.transparent,
        ],
        [0.0, 0.2, 0.5, 0.8, 1.0],
      )
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8);

    // ── Ligne principale fine ──
    final linePaint = Paint()
      ..shader = ui.Gradient.linear(
        Offset.zero,
        Offset(width, 0),
        [
          Colors.transparent,
          AppColors.laser.withOpacity(0.8),
          AppColors.laser,
          AppColors.laser.withOpacity(0.8),
          Colors.transparent,
        ],
        [0.0, 0.15, 0.5, 0.85, 1.0],
      )
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;

    // Dessiner le halo d'abord, puis la ligne par-dessus
    canvas.drawLine(
      Offset(0, size.height / 2),
      Offset(size.width, size.height / 2),
      glowPaint,
    );
    canvas.drawLine(
      Offset(0, size.height / 2),
      Offset(size.width, size.height / 2),
      linePaint,
    );
  }

  @override
  bool shouldRepaint(_LaserPainter oldDelegate) => oldDelegate.width != width;
}
