// ==================== FICHIER : lib/widgets/permission_request_view.dart ====================
// Écran affiché quand la permission caméra est manquante ou refusée.
// Design élégant et explicatif, cohérent avec le dark theme.

import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import 'glass_button.dart';

/// Vue affichée quand la permission caméra est absente.
class PermissionRequestView extends StatelessWidget {
  const PermissionRequestView({
    super.key,
    required this.onRequestPermission,
    this.isPermanentlyDenied = false,
  });

  final VoidCallback onRequestPermission;

  /// Si true, l'app a été bloquée définitivement → guider vers les Paramètres.
  final bool isPermanentlyDenied;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.xl),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Icône caméra stylisée
            Container(
              width: 88,
              height: 88,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: AppColors.laser, width: 1.5),
                color: AppColors.laser.withOpacity(0.08),
              ),
              child: const Icon(
                Icons.photo_camera_outlined,
                size: 40,
                color: AppColors.laser,
              ),
            ),
            const SizedBox(height: AppSpacing.lg),

            // Titre
            Text(
              isPermanentlyDenied ? 'Accès refusé' : 'Accès à la caméra',
              style: Theme.of(context).textTheme.headlineMedium,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: AppSpacing.sm),

            // Description
            Text(
              isPermanentlyDenied
                  ? 'La permission caméra a été refusée définitivement. '
                    'Veuillez l\'activer dans les Paramètres de votre appareil.'
                  : 'Cette application a besoin d\'accéder à votre caméra '
                    'pour scanner les QR codes.',
              style: Theme.of(context).textTheme.bodyMedium,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: AppSpacing.xl),

            // Bouton action
            GlassContainer(
              padding: EdgeInsets.zero,
              borderRadius: BorderRadius.circular(AppRadius.lg),
              child: InkWell(
                onTap: onRequestPermission,
                borderRadius: BorderRadius.circular(AppRadius.lg),
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: AppSpacing.xl,
                    vertical: AppSpacing.md,
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        isPermanentlyDenied
                            ? Icons.settings_outlined
                            : Icons.camera_alt_outlined,
                        color: AppColors.laser,
                        size: 20,
                      ),
                      const SizedBox(width: AppSpacing.sm),
                      Text(
                        isPermanentlyDenied
                            ? 'Ouvrir les Paramètres'
                            : 'Autoriser la caméra',
                        style: TextStyle(
                          color: AppColors.laser,
                          fontWeight: FontWeight.w600,
                          fontSize: 15,
                          letterSpacing: 0.3,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
