// ==================== FICHIER : lib/widgets/glass_button.dart ====================
//
// Implémentation du Glassmorphism (frosted glass) :
//   1. ClipRRect    – découpe la forme en coins arrondis.
//   2. BackdropFilter (ImageFilter.blur) – applique le flou de fond (blur: 14).
//   3. Container avec couleur semi-transparente – la "teinte" du verre.
//   4. DecoratedBox avec bordure fine – le contour lumineux.
//
// Cette approche est la SEULE correcte en Flutter pour obtenir un vrai
// effet de verre dépoli qui floute ce qui est DERRIÈRE le widget.

import 'dart:ui';

import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

// ─────────────────────────────────────────────────────────────
// GlassContainer – conteneur glassmorphism générique
// ─────────────────────────────────────────────────────────────

/// Conteneur glassmorphism réutilisable.
/// Enveloppe n'importe quel [child] avec l'effet frosted glass.
class GlassContainer extends StatelessWidget {
  const GlassContainer({
    super.key,
    required this.child,
    this.borderRadius = const BorderRadius.all(Radius.circular(AppRadius.md)),
    this.padding = const EdgeInsets.all(AppSpacing.md),
    this.blur = 14.0,
    this.fillOpacity = 0.12,
    this.borderOpacity = 0.22,
  });

  final Widget child;
  final BorderRadius borderRadius;
  final EdgeInsetsGeometry padding;

  /// Force du flou BackdropFilter.
  final double blur;

  /// Opacité du fond blanc (0.0 – 1.0).
  final double fillOpacity;

  /// Opacité de la bordure blanche (0.0 – 1.0).
  final double borderOpacity;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: borderRadius,
      child: BackdropFilter(
        // Flou élevé pour l'effet de verre dépoli
        filter: ImageFilter.blur(sigmaX: blur, sigmaY: blur),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            // Fond semi-transparent (couleur du "verre")
            color: Colors.white.withOpacity(fillOpacity),
            borderRadius: borderRadius,
            border: Border.all(
              color: Colors.white.withOpacity(borderOpacity),
              width: 1.0,
            ),
          ),
          child: child,
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────
// GlassIconButton – bouton icône glassmorphism
// ─────────────────────────────────────────────────────────────

/// Bouton icône avec fond glassmorphism.
/// Utilisé pour Flash, Galerie, Historique, etc.
class GlassIconButton extends StatefulWidget {
  const GlassIconButton({
    super.key,
    required this.icon,
    required this.onTap,
    this.label,
    this.size = 56.0,
    this.iconSize = 22.0,
    this.isActive = false,
    this.activeColor = AppColors.laser,
  });

  final IconData icon;
  final VoidCallback onTap;

  /// Libellé optionnel affiché sous l'icône.
  final String? label;

  /// Taille du bouton (carré).
  final double size;

  /// Taille de l'icône.
  final double iconSize;

  /// Si true, l'icône prend la couleur [activeColor].
  final bool isActive;
  final Color activeColor;

  @override
  State<GlassIconButton> createState() => _GlassIconButtonState();
}

class _GlassIconButtonState extends State<GlassIconButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pressCtrl;
  late final Animation<double> _scaleAnim;

  @override
  void initState() {
    super.initState();
    _pressCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 120),
      lowerBound: 0.92,
      upperBound: 1.0,
      value: 1.0,
    );
    _scaleAnim = _pressCtrl;
  }

  @override
  void dispose() {
    _pressCtrl.dispose();
    super.dispose();
  }

  // Animation d'appui : scale down → scale up
  Future<void> _handleTap() async {
    await _pressCtrl.reverse();
    widget.onTap();
    await _pressCtrl.forward();
  }

  @override
  Widget build(BuildContext context) {
    final iconColor = widget.isActive ? widget.activeColor : AppColors.textPrimary;

    return GestureDetector(
      onTap: _handleTap,
      child: AnimatedBuilder(
        animation: _scaleAnim,
        builder: (context, child) =>
            Transform.scale(scale: _scaleAnim.value, child: child),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            GlassContainer(
              padding: EdgeInsets.zero,
              borderRadius: BorderRadius.circular(widget.size / 2),
              child: SizedBox(
                width: widget.size,
                height: widget.size,
                child: Center(
                  child: Icon(widget.icon, size: widget.iconSize, color: iconColor),
                ),
              ),
            ),
            if (widget.label != null) ...[
              const SizedBox(height: AppSpacing.xs),
              Text(
                widget.label!,
                style: Theme.of(context).textTheme.labelSmall,
              ),
            ],
          ],
        ),
      ),
    );
  }
}
