// ==================== FICHIER : lib/services/history_service.dart ====================
// Service de persistance de l'historique des scans via SharedPreferences.
// Singleton accessible depuis toute l'application.

import 'package:shared_preferences/shared_preferences.dart';

import '../models/scan_result_model.dart';

/// Gère la persistance et la récupération de l'historique de scans.
class HistoryService {
  HistoryService._();
  static final HistoryService instance = HistoryService._();

  static const String _storageKey = 'scan_history';
  static const int _maxHistorySize = 100; // Limite pour éviter un stockage excessif

  /// Ajoute un scan à l'historique.
  Future<void> addScan(ScanResultModel scan) async {
    final prefs = await SharedPreferences.getInstance();
    final history = await getHistory();

    // Dédoublonner : on n'ajoute pas si l'URL est déjà le scan le plus récent
    if (history.isNotEmpty && history.first.url == scan.url) return;

    history.insert(0, scan);

    // Tronquer si nécessaire
    if (history.length > _maxHistorySize) {
      history.removeRange(_maxHistorySize, history.length);
    }

    await prefs.setStringList(
      _storageKey,
      history.map((e) => e.toJsonString()).toList(),
    );
  }

  /// Récupère tout l'historique trié du plus récent au plus ancien.
  Future<List<ScanResultModel>> getHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final rawList = prefs.getStringList(_storageKey) ?? [];

    return rawList
        .map((raw) {
          try {
            return ScanResultModel.fromJsonString(raw);
          } catch (_) {
            return null;
          }
        })
        .whereType<ScanResultModel>()
        .toList();
  }

  /// Supprime tout l'historique.
  Future<void> clearHistory() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_storageKey);
  }

  /// Supprime une entrée spécifique par son ID.
  Future<void> removeById(String id) async {
    final prefs = await SharedPreferences.getInstance();
    final history = await getHistory();
    history.removeWhere((e) => e.id == id);
    await prefs.setStringList(
      _storageKey,
      history.map((e) => e.toJsonString()).toList(),
    );
  }
}
