// ==================== FICHIER : lib/services/url_service.dart ====================
// Service responsable de la validation et de l'ouverture des URLs.

import 'package:url_launcher/url_launcher.dart';

/// Utilitaires pour valider et ouvrir des URLs dans le navigateur système.
abstract final class UrlService {
  /// Retourne true si [rawUrl] commence par http:// ou https://.
  static bool isValidUrl(String rawUrl) {
    final trimmed = rawUrl.trim().toLowerCase();
    return trimmed.startsWith('http://') || trimmed.startsWith('https://');
  }

  /// Ouvre [rawUrl] dans le navigateur par défaut.
  /// Retourne true si le lancement a réussi, false sinon.
  static Future<bool> openUrl(String rawUrl) async {
    final uri = Uri.tryParse(rawUrl.trim());
    if (uri == null) return false;

    try {
      final canLaunch = await canLaunchUrl(uri);
      if (!canLaunch) return false;

      return launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {
      return false;
    }
  }
}
