// ==================== FICHIER : lib/models/scan_result_model.dart ====================
// Modèle de données représentant un scan QR enregistré dans l'historique.

import 'dart:convert';

/// Représente un résultat de scan QR sauvegardé.
class ScanResultModel {
  final String id;
  final String url;
  final DateTime scannedAt;

  const ScanResultModel({
    required this.id,
    required this.url,
    required this.scannedAt,
  });

  /// Convertit le modèle en Map JSON-sérialisable.
  Map<String, dynamic> toJson() => {
    'id': id,
    'url': url,
    'scannedAt': scannedAt.toIso8601String(),
  };

  /// Construit le modèle depuis une Map JSON.
  factory ScanResultModel.fromJson(Map<String, dynamic> json) =>
      ScanResultModel(
        id: json['id'] as String,
        url: json['url'] as String,
        scannedAt: DateTime.parse(json['scannedAt'] as String),
      );

  /// Sérialise vers une chaîne JSON (pour SharedPreferences).
  String toJsonString() => jsonEncode(toJson());

  /// Désérialise depuis une chaîne JSON (depuis SharedPreferences).
  factory ScanResultModel.fromJsonString(String source) =>
      ScanResultModel.fromJson(
        jsonDecode(source) as Map<String, dynamic>,
      );
}
