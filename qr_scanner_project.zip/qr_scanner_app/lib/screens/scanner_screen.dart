// ==================== FICHIER : lib/screens/scanner_screen.dart ====================
//
// Écran principal de scan. Responsabilités :
//   • Demande de permission caméra via permission_handler
//   • Instanciation et cycle de vie de MobileScannerController
//   • Détection et traitement des QR codes (debounce via _isProcessing)
//   • Déclenchement du HapticFeedback + ouverture URL
//   • Contrôle de la torche + import depuis la galerie
//   • Affichage de l'UI (overlay, boutons glassmorphism, historique)

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:uuid/uuid.dart';

import '../models/scan_result_model.dart';
import '../services/history_service.dart';
import '../services/url_service.dart';
import '../theme/app_theme.dart';
import '../widgets/glass_button.dart';
import '../widgets/permission_request_view.dart';
import '../widgets/scanner_overlay.dart';
import '../widgets/success_flash.dart';
import 'history_screen.dart';

// ─────────────────────────────────────────────────────────────
// ScannerScreen
// ─────────────────────────────────────────────────────────────

class ScannerScreen extends StatefulWidget {
  const ScannerScreen({super.key});

  @override
  State<ScannerScreen> createState() => _ScannerScreenState();
}

class _ScannerScreenState extends State<ScannerScreen>
    with WidgetsBindingObserver {
  // ── Contrôleur MobileScanner ──
  late final MobileScannerController _scannerCtrl;

  // ── États UI ──
  _PermissionState _permissionState = _PermissionState.checking;
  bool _isTorchOn = false;
  bool _isProcessing = false; // debounce : évite d'ouvrir l'URL plusieurs fois
  bool _showSuccess = false;

  final Uuid _uuid = const Uuid();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);

    _scannerCtrl = MobileScannerController(
      detectionSpeed: DetectionSpeed.noDuplicates,
      returnImage: false,
      formats: const [BarcodeFormat.qrCode],
    );

    _checkCameraPermission();
  }

  // ── Cycle de vie : pause/reprise de la caméra selon la visibilité ──

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    switch (state) {
      case AppLifecycleState.paused:
      case AppLifecycleState.inactive:
      case AppLifecycleState.hidden:
        _scannerCtrl.stop();
      case AppLifecycleState.resumed:
        if (_permissionState == _PermissionState.granted) {
          _scannerCtrl.start();
        }
      case AppLifecycleState.detached:
        break;
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _scannerCtrl.dispose();
    super.dispose();
  }

  // ─────────────────────────────────────────────────────────────
  // Gestion des permissions caméra
  // ─────────────────────────────────────────────────────────────

  Future<void> _checkCameraPermission() async {
    final status = await Permission.camera.status;
    _applyPermissionStatus(status);
  }

  Future<void> _requestPermission() async {
    // Si bloquée définitivement → ouvrir les Paramètres système
    if (_permissionState == _PermissionState.permanentlyDenied) {
      await openAppSettings();
      return;
    }
    final status = await Permission.camera.request();
    _applyPermissionStatus(status);
  }

  void _applyPermissionStatus(PermissionStatus status) {
    setState(() {
      if (status.isGranted) {
        _permissionState = _PermissionState.granted;
      } else if (status.isPermanentlyDenied) {
        _permissionState = _PermissionState.permanentlyDenied;
      } else {
        _permissionState = _PermissionState.denied;
      }
    });
  }

  // ─────────────────────────────────────────────────────────────
  // Traitement d'un QR code détecté
  // ─────────────────────────────────────────────────────────────

  Future<void> _onDetect(BarcodeCapture capture) async {
    // Debounce : ignorer si on traite déjà un code
    if (_isProcessing) return;

    final barcode = capture.barcodes.firstOrNull;
    final rawValue = barcode?.rawValue;
    if (rawValue == null || rawValue.isEmpty) return;

    // Valider que c'est une URL http/https
    if (!UrlService.isValidUrl(rawValue)) return;

    // ── Marquer comme "en traitement" ──
    _isProcessing = true;

    // 1. Vibration légère
    await HapticFeedback.lightImpact();

    // 2. Animation de succès
    if (mounted) setState(() => _showSuccess = true);

    // 3. Toast de confirmation
    Fluttertoast.showToast(
      msg: 'Ouverture du lien…',
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      backgroundColor: AppColors.surface.withOpacity(0.92),
      textColor: AppColors.textPrimary,
      fontSize: 13.5,
    );

    // 4. Sauvegarder dans l'historique
    await HistoryService.instance.addScan(
      ScanResultModel(
        id: _uuid.v4(),
        url: rawValue,
        scannedAt: DateTime.now(),
      ),
    );

    // 5. Petite pause pour laisser l'animation s'afficher (~400 ms)
    await Future.delayed(const Duration(milliseconds: 400));

    // 6. Ouvrir l'URL
    final opened = await UrlService.openUrl(rawValue);
    if (!opened && mounted) {
      Fluttertoast.showToast(
        msg: 'Impossible d\'ouvrir ce lien',
        backgroundColor: Colors.red.shade900,
        textColor: AppColors.textPrimary,
      );
    }

    // 7. Réinitialiser après un délai (évite les doubles scans en reprenant)
    await Future.delayed(const Duration(milliseconds: 1600));
    if (mounted) {
      setState(() {
        _showSuccess = false;
        _isProcessing = false;
      });
    }
  }

  // ─────────────────────────────────────────────────────────────
  // Actions boutons
  // ─────────────────────────────────────────────────────────────

  Future<void> _toggleTorch() async {
    await _scannerCtrl.toggleTorch();
    setState(() => _isTorchOn = !_isTorchOn);
  }

  Future<void> _importFromGallery() async {
    final result = await _scannerCtrl.analyzeImage(null);
    if (result != null && result.barcodes.isNotEmpty) {
      await _onDetect(result);
    } else {
      Fluttertoast.showToast(
        msg: 'Aucun QR code trouvé dans l\'image',
        backgroundColor: AppColors.surface.withOpacity(0.92),
        textColor: AppColors.textPrimary,
      );
    }
  }

  void _openHistory() {
    _scannerCtrl.stop();
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const HistoryScreen()),
    ).then((_) {
      if (_permissionState == _PermissionState.granted) {
        _scannerCtrl.start();
      }
    });
  }

  // ─────────────────────────────────────────────────────────────
  // Build
  // ─────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      extendBodyBehindAppBar: true,
      body: switch (_permissionState) {
        _PermissionState.checking => const Center(
          child: CircularProgressIndicator(color: AppColors.laser),
        ),
        _PermissionState.denied || _PermissionState.permanentlyDenied => SafeArea(
          child: PermissionRequestView(
            onRequestPermission: _requestPermission,
            isPermanentlyDenied: _permissionState == _PermissionState.permanentlyDenied,
          ),
        ),
        _PermissionState.granted => _buildScannerUI(),
      },
    );
  }

  Widget _buildScannerUI() {
    return Stack(
      fit: StackFit.expand,
      children: [
        // ── Caméra plein écran ──
        MobileScanner(
          controller: _scannerCtrl,
          onDetect: _onDetect,
          fit: BoxFit.cover,
        ),

        // ── Overlay (assombrissement + cadre + laser) ──
        ScannerOverlay(isScanning: !_isProcessing),

        // ── Flash de succès ──
        SuccessFlash(show: _showSuccess),

        // ── UI supérieure : titre + statut ──
        _buildTopUI(),

        // ── UI inférieure : boutons glassmorphism ──
        _buildBottomControls(),
      ],
    );
  }

  // ── Zone supérieure ──

  Widget _buildTopUI() {
    return Positioned(
      top: 0,
      left: 0,
      right: 0,
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(
            horizontal: AppSpacing.lg,
            vertical: AppSpacing.md,
          ),
          child: Column(
            children: [
              // Titre de l'app
              Text(
                'QR SCANNER',
                style: TextStyle(
                  color: AppColors.textPrimary.withOpacity(0.9),
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 3.5,
                ),
              ),
              const SizedBox(height: AppSpacing.xxl + AppSpacing.lg),

              // Instruction de scan
              GlassContainer(
                padding: const EdgeInsets.symmetric(
                  horizontal: AppSpacing.md,
                  vertical: AppSpacing.sm,
                ),
                borderRadius: BorderRadius.circular(AppRadius.xl),
                blur: 10,
                fillOpacity: 0.08,
                child: Text(
                  'Placez le QR code dans le cadre',
                  style: TextStyle(
                    color: AppColors.textPrimary.withOpacity(0.75),
                    fontSize: 13,
                    letterSpacing: 0.3,
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── Zone inférieure ──

  Widget _buildBottomControls() {
    return Positioned(
      bottom: 0,
      left: 0,
      right: 0,
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.only(
            bottom: AppSpacing.xl,
            left: AppSpacing.lg,
            right: AppSpacing.lg,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              // Bouton Flash / Torche
              GlassIconButton(
                icon: _isTorchOn
                    ? Icons.flashlight_on_rounded
                    : Icons.flashlight_off_rounded,
                onTap: _toggleTorch,
                label: _isTorchOn ? 'Flash ON' : 'Flash',
                isActive: _isTorchOn,
              ),

              // Bouton Galerie
              GlassIconButton(
                icon: Icons.photo_library_outlined,
                onTap: _importFromGallery,
                label: 'Galerie',
              ),

              // Bouton Historique
              GlassIconButton(
                icon: Icons.history_rounded,
                onTap: _openHistory,
                label: 'Historique',
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────
// Enum état de la permission caméra
// ─────────────────────────────────────────────────────────────

enum _PermissionState {
  checking,
  granted,
  denied,
  permanentlyDenied,
}
